from resources.lib import main
if __name__=='__main__':main.run()